/**
 * http://kopatheme.com
 * Copyright (c) 2016 Kopatheme
 *
 * Licensed under the GPL license:
 *  http://www.gnu.org/licenses/gpl.html
 **/

(function($) {
	"use strict";
	
	$( window ).load(function() {
		
		// Filter Img & replace to placehold.it
		$('body').imagesLoaded(function() {
			
			var $url =  window.location.href;
			
			$.ajax({
				url: $url,
				cache: false,
			}).done(function( html ) {
				
				var $html = html;
				
				$('body').find('img').each(function() {
					var $this 	= $(this),
						$width 	= $this.width(),
						$height	= $this.height(),
						$src	= "http://placehold.it/" + $width + "x" + $height + "/333";
					
					$html = $html.replace($this.attr("src"), $src); 
				});
				
				console.log($html);
				
				//var image = new Image();
			    //image.src = $('.page-header').css('background-image').replace(/url\((['"])?(.*?)\1\)/gi, '$2').split(',')[0];
			    //console.log(image.src);
			    //var width = image.width,
			     	//height = image.height; 
			});
		}); // End Placehold
		
		if ( $('.services-detail-v2').length > 0 ) { 
			
			$('.services-detail-v2 .sidebar-inner').css( "width", $('.services-detail-v2 .sidebar-inner').innerWidth());
			
			if ( $('.services-detail-v2 .sidebar').innerHeight() < $('.services-detail-v2 .post').innerHeight() )
				$('.services-detail-v2 .sidebar').css( "min-height", $('.services-detail-v2 .post').innerHeight());
		}
		
		if ( $('.services-detail-v2').length > 0 ) {
			var $scrollTop;
			$(window).scroll(function(){
				$scrollTop = $(window).scrollTop() - $('.services-detail-v2 .sidebar').offset().top - $('.services-detail-v2 .sidebar').height() + $('.services-detail-v2 .sidebar-inner').height();
				
				if ( $scrollTop >= 0 || $(window).scrollTop() - $('.sidebar').offset().top <= 0 ) {
					$('.services-detail-v2 .sidebar-inner').removeClass('sidebar-stuck');
				} else if ( $(window).scrollTop() - $('.sidebar').offset().top > 0 )
					$('.services-detail-v2 .sidebar-inner').addClass('sidebar-stuck');
			  
			});
		}
		
		$('body').find('.section').each( function() {
			var $section = $(this);
			new Waypoint({
				element: $section[0],
				handler: function(direction) {
					
					var $element = $(this.element);
					
					$element.find('.animated').each(function() {
						var $animate = $(this).attr('data-animate');
						if ( typeof $animate !== "undefined" ){
							$(this).addClass($animate);
						};
			    		
			    	});
				},
				offset: '55%',
			});
		});
	
		
		// Progress
		$('body').find('.progress-box').each( function(e) {
			var $progress = $(this);
			
			new Waypoint({
				element: $progress[0],
				handler: function(direction) {
					
					var $element = $(this.element);
					
					if ( $element.hasClass('progress-box-v3') && $element.find('svg').length < 1 ) {
						
						$element.find('.progress-svg').each( function() {
							var $this 		= $(this),
							    $value		= $this.data('value'),
							    $color 		= $this.data('color'),
							    $trailColor	= $this.data('trailColor');
							
								var bar = new ProgressBar.Line($this[0], {
									  strokeWidth: 0.8,
									  easing: 'easeInOut',
									  duration: 2500,
									  trailWidth: 0.8,
									  color: $color,
									  trailColor: $trailColor,
									  svgStyle: {width: '100%', height: '100%'},
									  text: {
										    style: {
										      left: ($value * 100) + '%',
										      bottom: '100%',
										      position: 'absolute',
										      transform: {
										    	  prefix: true,
										    	  value: 'translate(-100%, 0)'
										      }
										    },
										    autoStyleContainer: true
									  },
									  step: function (state, bar) {
										  bar.setText(Math.round(bar.value() * 100 ) + '%');
									  }
								});
								bar.animate($value);
						});
						
					} else if ( $element.find('svg').length < 1 ) {
						
						$element.find('.progress-svg').each( function() {
							var $this 	= $(this),
							    $value	= $this.data('value');
							
								var bar = new ProgressBar.Line($this[0], {
									  strokeWidth: 0,
									  easing: 'easeInOut',
									  duration: 2500,
									  trailWidth: 0,
									  svgStyle: {
									        display: 'none',
									    },
									  text: {
										    style: {
										      position: 'static',
										      transform: null
										    },
										    autoStyleContainer: false
									  },
									  step: function (state, bar) {
										  bar.setText(Math.round(bar.value()));
									 }
								});
								bar.animate($value);
						});
					}
					
				},
				offset: '100%',
			});
		}); 
	});
	
	
	$(document).ready(function() {
		
		// Mega menu
		mtheme_mage_menu();
		
		$('.header-search').on('click', 'a.button', function(e) {
			e.preventDefault();
			
			$(this).parents('.header-search').toggleClass('active');
		})
		/*
		$('.header-search').on('click', 'a.remove', function(e) {
			e.preventDefault();
			
			$(this).parents('.header-search').toggleClass('active');
		})*/
		/*
		$('.header-search').on('focus ', 'input', function(e) {
			e.preventDefault();
			
			$(this).parents('.header-search').toggleClass('active');
		})
		$('body').on('click', function(e){
			if ( $(e.target).closest('.header-search' ).length < 1 && $(e.target).parents('.header-search' ).length < 1) {
              	$('.header-search').removeClass('active');
            };
		})*/
		
		/**
		    sliceDown
		    sliceDownLeft
		    sliceUp
		    sliceUpLeft
		    sliceUpDown
		    sliceUpDownLeft
		    fold
		    fade
		    random
		    slideInRight
		    slideInLeft
		    boxRandom
		    boxRain
		    boxRainReverse
		    boxRainGrow
		    boxRainGrowReverse
		*/
		// Slider Slider
		var $slider = $('#slider .slider-wrapper');
		if ( $slider.length > 0 ) {
			$slider.imagesLoaded(function() {
				$slider.find('.nivoSlider').nivoSlider({
					pauseTime: 10000,
					directionNav: true,
				    controlNav: false,
				    randomStart: false, 
				    beforeChange: function(){
				    	$slider.find('.nivo-caption').find('.animated').each(function() {
				    		$(this).addClass('fadeOut');
				    	});
				    },    
				    afterChange: function(){
				    	$slider.find('.nivo-caption').find('.animated').each(function() {
				    		$(this).addClass($(this).attr('data-animate'));
				    	});
				    },        
				    slideshowEnd: function(){
				    },     
				    lastSlide: function(){
				    },         
				    afterLoad: function(){
				    	$slider.find('.nivo-caption').find('.animated').each(function() {
				    		$(this).addClass($(this).attr('data-animate'));
				    	});
				    },         
				});
			});
		}
		
		
		/* Instagram Feed */
		var $instafeed = $('#instafeed');
		
		if ( $instafeed.length > 0 ) {
			
			 var userFeed = new Instafeed({
		        get: 'user',
		        userId: '1781628684',
		        accessToken: '1781628684.aca4523.ed510037eb3444cebc3a38882d392680',
		        template: '<div class="instagram_thumbnail"><a href="{{link}}"><img src="{{image}}" /></a></div>',
		        limit: 9
		    });
		    userFeed.run();
		}
		
		
		// Flickity slider
		//Service Slider
		if ( $('.service-slider .slider-flickity').length > 0 ) {
			$('.service-slider .slider-flickity').imagesLoaded(function() {
				$('.service-slider .slider-flickity').flickity({
					contain: true,
					imagesLoaded: true,
					prevNextButtons: true,
					pageDots: false,
					cellAlign: 'left',
					arrowShape: { 
						  x0: 30,
						  x1: 60, y1: 30,
						  x2: 70, y2: 30,
						  x3: 40
						}
				});
			});
		}
		//Testimonial v1
		if ( $('.testimonial-slider .slider-flickity').length > 0 ) {
			$('.testimonial-slider .slider-flickity').imagesLoaded(function() {
				$('.testimonial-slider .slider-flickity').flickity({
					wrapAround: true,
					imagesLoaded: true,
					prevNextButtons: true,
					pageDots: false,
					arrowShape: { 
						  x0: 30,
						  x1: 60, y1: 30,
						  x2: 70, y2: 30,
						  x3: 40
						}
				});
			});
		}
		//Testimonial v2
		if ( $('.testimonial-slider-v2 .slider-flickity').length > 0 ) {
			$('.testimonial-slider-v2 .slider-flickity').imagesLoaded(function() {
				$('.testimonial-slider-v2 .slider-flickity').flickity({
					wrapAround: true,
					imagesLoaded: true,
					prevNextButtons: false,
					pageDots: true,
				});
			});
		}
		//Testimonial v3
		if ( $('.testimonial-slider-v3 .slider-flickity').length > 0 ) {
			$('.testimonial-slider-v3 .slider-flickity').imagesLoaded(function() {
				$('.testimonial-slider-v3 .slider-flickity').flickity({
					contain: true,
					imagesLoaded: true,
					prevNextButtons: false,
					pageDots: false,
					cellAlign: 'left',
					arrowShape: { 
						  x0: 30,
						  x1: 60, y1: 30,
						  x2: 70, y2: 30,
						  x3: 40
						}
				});
			});
		}
		//Testimonial v4
		if ( $('.testimonial-slider-v4 .slider-flickity').length > 0 ) {
			$('.testimonial-slider-v4 .slider-flickity').imagesLoaded(function() {
				$('.testimonial-slider-v4 .slider-flickity').flickity({
					wrapAround: true,
					imagesLoaded: true,
					prevNextButtons: false,
					pageDots: false,
					arrowShape: { 
						  x0: 30,
						  x1: 60, y1: 30,
						  x2: 70, y2: 30,
						  x3: 40
						}
				});
			});
		}
		//Testimonial v5
		if ( $('.testimonial-slider-v5 .slider-flickity').length > 0 ) {
			$('.testimonial-slider-v5 .slider-flickity').imagesLoaded(function() {
				$('.testimonial-slider-v5 .slider-flickity').flickity({
					wrapAround: true,
					imagesLoaded: true,
					prevNextButtons: false,
					pageDots: false,
					cellAlign: 'left',
					arrowShape: { 
						  x0: 30,
						  x1: 60, y1: 30,
						  x2: 70, y2: 30,
						  x3: 40
						}
				});
			});
		}
		//Testimonial v7
		if ( $('.testimonial-slider-v7 .slider-flickity').length > 0 ) {
			$('.testimonial-slider-v7 .slider-flickity').imagesLoaded(function() {
				$('.testimonial-slider-v7 .slider-flickity').flickity({
					wrapAround: true,
					imagesLoaded: true,
					prevNextButtons: false,
					pageDots: false,
				});
			});
		}
		
		//Blog Slider
		if ( $('.blog-slider .slider-flickity').length > 0 ) {
			$('.blog-slider .slider-flickity').imagesLoaded(function() {
				$('.blog-slider .slider-flickity').flickity({
					contain: true,
					imagesLoaded: true,
					prevNextButtons: false,
					pageDots: false,
					cellAlign: 'left',
					arrowShape: { 
						  x0: 30,
						  x1: 60, y1: 30,
						  x2: 70, y2: 30,
						  x3: 40
						}
				});
			});
		}
		
		//Related Products
		if ( $('.related-product-slider .slider-flickity').length > 0 ) {
			$('.related-product-slider .slider-flickity').imagesLoaded(function() {
				$('.related-product-slider .slider-flickity').flickity({
					contain: true,
					imagesLoaded: true,
					prevNextButtons: false,
					pageDots: false,
					cellAlign: 'left',
					arrowShape: { 
						  x0: 30,
						  x1: 60, y1: 30,
						  x2: 70, y2: 30,
						  x3: 40
						}
				});
			});
		}
		
		
		//Meet Our Team
		if ( $('.our-team-slider .slider-flickity').length > 0 ) {
			$('.our-team-slider .slider-flickity').imagesLoaded(function() {
				var $our_team_slider = $('.our-team-slider .slider-flickity').flickity({
					wrapAround: true,
					imagesLoaded: true,
					prevNextButtons: false,
					pageDots: false,
				});
				
				// 2nd carousel, navigation
				$('.our-team-slider .slider-thumbs').flickity({
				  asNavFor: '.our-team-slider .slider-flickity',
				  contain: true,
				  pageDots: false,
				  prevNextButtons: false,
				  cellAlign: 'left'
				});
				
				
				// Flickity instance
				var flkty = $our_team_slider.data('flickity');
				
				// elements
				var $slider_contents = $('.slider-contents');
				var $slider_content = $slider_contents.find('.slider-content');
				
				// update selected cellButtons
				$our_team_slider.on( 'cellSelect', function() {
					$slider_content.filter('.is-selected').removeClass('is-selected');
					$slider_content.eq( flkty.selectedIndex ).addClass('is-selected');
				});
				
			});
		}
		//Our Team Slider v2
		if ( $('.our-team-slider-v2 .slider-flickity').length > 0 ) {
			$('.our-team-slider-v2 .slider-flickity').imagesLoaded(function() {
				var $our_team_slider = $('.our-team-slider-v2 .slider-flickity').flickity({
					contain: true,
					imagesLoaded: true,
					prevNextButtons: false,
					pageDots: false,
					cellAlign: 'left',
				});
				
			});
		}
		//Client Logo
		if ( $('.client-logo-slider .slider-flickity').length > 0 ) {
			$('.client-logo-slider .slider-flickity').imagesLoaded(function() {
				$('.client-logo-slider .slider-flickity').flickity({
					contain: true,
					imagesLoaded: true,
					prevNextButtons: false,
					pageDots: false,
					cellAlign: 'left'
				});
			});
		}
		
		
		// Filter
		var $filter = $('.filter');
		if ( $filter.length > 0 ) {
			
			// filter items
			$filter.on('click', 'button', function() {
				var $this 		= $(this),
					filterValue = $this.attr('data-filter'),
					item 		= '.product',
					$i 			= 0;
			
				if ( $filter.siblings('.work-items').length > 0 )
					item = '.work-item';
				
				if ( $this.hasClass('active') )
					return false;
				
				$this.addClass('active');
				$this.siblings('.active').removeClass('active');
				
				if ( filterValue == '*' ) filterValue = item;
				
				$filter.parent().find(item).removeClass('first').not(filterValue).fadeOut(1000);
				$filter.parent().find(filterValue).fadeIn(1000).each( function(){
					
					$i++;
					
					if ( item == '.work-item' && $i%3 == 1 ) {
						$(this).addClass('first');
						
					} else if ( item == '.product' && $i%4 == 1) {
						$(this).addClass('first');
					}

				} );
				
				return false;
			});
		}
		
		$('.accordion').on('shown.bs.collapse', function () {
			var $this = $(this);
			
			$this.find('.panel').removeClass('active').find('.panel-collapse').filter('.in').parent().addClass('active');
		})
	});
	
	// Mega menu
	function mtheme_mage_menu() {
		
		var $mega = $('.mega-wrap'),
			position_left = 0;
		
		$mega.imagesLoaded(function() {
			$mega.each( function() {
				
				var $this = $(this);
	
				if ( $this.hasClass('full-width') ) {
					position_left = $this.offset().left - ($(window).innerWidth() - $this.innerWidth())/2;
					$this.css({
			            'left': -position_left
			        });
					
				} else if ( $this.hasClass('pos-center') ) {
					position_left = $this.innerWidth()/2;
					$this.css({
			            'left': -position_left
			        });
				}
				
				var $height = 0;
				$this.find('.mega-item').each(function(){
					if ( $height < $(this).innerHeight() ) $height = $(this).innerHeight();
				  });
				$this.find('.mega-item').css("min-height", $height);
			});
		});
	}
    
})(jQuery);


var mtheme_maps = 
				[
				 	{ 
						LatLng: "-37.8172229, 144.9543313",
				 	}
				];
	
	function initialize( $canvas, $options ) {
		
		var grayStyles = [{"featureType":"landscape.natural","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"color":"#e0efef"}]},{"featureType":"poi","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"hue":"#1900ff"},{"color":"#c0e8e8"}]},{"featureType":"road","elementType":"geometry","stylers":[{"lightness":100},{"visibility":"simplified"}]},{"featureType":"road","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"transit.line","elementType":"geometry","stylers":[{"visibility":"on"},{"lightness":700}]},{"featureType":"water","elementType":"all","stylers":[{"color":"#7dcdcd"}]}];
		
		
		// Multi Maps
		var mapOptions,
			map,
			$LatLng,
			i,
			marker = [],
			infowindow = [];
		
		$LatLng = $options[0].LatLng.split(", "); 
		
		mapOptions = {
				center : new google.maps.LatLng($LatLng[0], $LatLng[1]),
				zoom : 16,
				styles : grayStyles,
				
				panControl: false,
				zoomControl: true,
				mapTypeControl: false,
				streetViewControl: false,
				scrollwheel: false, 
				mapTypeId: google.maps.MapTypeId.ROADMAP,
			};
			
		map = new google.maps.Map($canvas,
				mapOptions);
		
		for ( i = 0; i < $options.length; i++ ) {
			
			var $_LatLng = $options[i].LatLng.split(", "); 
			
			marker[i] = new google.maps.Marker({
				map : map,
				position : new google.maps.LatLng($_LatLng[0], $_LatLng[1]),
				icon: 'imgs/icon-map.png',
				key: i,
			});
		
			if (  typeof $options[i].desc_contact !== "undefined" && $options[i].desc_contact.length > 0 ) {
				infowindow[i] = new google.maps.InfoWindow();
				infowindow[i].setContent($options[i].desc_contact); 
				
				//infowindow[i].open(map, marker[i]);
				google.maps.event.addListener(marker[i], 'click', function() {
					infowindow[this.key].open(map, marker[this.key]);
				}); 
			}
		}
	}


var $map_canvas = document.getElementById("map-canvas");

if ( typeof mtheme_maps !== "undefined" && mtheme_maps.length > 0 && $map_canvas != null) {
	google.maps.event.addDomListener(window, 'load', initialize($map_canvas, mtheme_maps ));
}

